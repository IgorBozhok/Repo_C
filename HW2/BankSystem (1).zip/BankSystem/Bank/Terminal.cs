﻿using System;
using BankLib;

namespace BankSystem
{
    class Terminal
    {
        public static Client RegistrationClientForm()
        {
            Console.Write("Введите логин: ");
            string login = Console.ReadLine();

            string passwd;

            while (true)
            {
                Console.Write("Введите пароль (пароль должен быть не менее 6 символов и содержать символы верхнего регистра): ");
                passwd = Console.ReadLine();
                if (!Banksecurity.SecurityCheckPasswd(passwd))
                {
                    Console.WriteLine("Неподходящий пароль");
                }
                else
                {
                    break;
                }
            }

            Console.Write("Введите имя: ");
            string firstName = Console.ReadLine();

            Console.Write("Введите фамилию: ");
            string lastName = Console.ReadLine();

            return new Client(lastName, firstName, login, passwd);
        }

        private static Account RegistrationAccountForm()
        {
            string numOfPas;

            while (true)
            {
                Console.Write("Введите номер паспорта (пример: 7123456А001РВ3): ");
                numOfPas = Console.ReadLine();
                if (!Banksecurity.CheckNumOfPassport(numOfPas))
                {
                    Console.Clear();
                    Console.WriteLine("Неверный номер паспорта");
                }
                else
                {
                    break;
                }
            }

            return new Account(numOfPas);
        }

        private static int ChoiseCheck(string menu)
        {
            while (true)
            {
                Console.WriteLine(menu);
                int choice = -1;
                try
                {
                    choice = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.Clear();
                    Console.WriteLine("введено не верное значение");
                    continue;
                }

                if (choice < 0 || choice > 2)
                {
                    Console.Clear();
                    Console.WriteLine("введено не верное значение");
                    continue;
                }
                else
                {
                    return choice;
                }
            }
        }

        public static int MainMenu()
        {
            return ChoiseCheck("1 - войти в личный кабинет;\n2 - создать личный кибинет;\n0 - выход.");
        }

        public static void ClientMenu(Client client)
        {
            Console.WriteLine("Добрый день {0}!", client.FirstName);

            bool exit = true;
            while (exit)
            {
                int choise = ChoiseCheck("1 - просмотр баланса ИП;\n2 - регистрация ИП\n0 - выход в главное меню.");

                switch (choise)
                {
                    case 1:
                        //todo
                        break;
                    case 2:
                        int index = client.SearchAFreeElem();
                        if (index == -1)
                        {
                            Console.WriteLine("Достигнуто максимальное количество ИП");
                        }
                        else
                        {
                            if (client.AddAccount(Terminal.RegistrationAccountForm()))
                            {
                                Console.Clear();
                                Console.WriteLine("Регистрация ИП прошлав успешно, номер ИП:{0}", client.getAccountIP(index));
                            }
                            else
                            {
                                Console.WriteLine("Ошибка при регистрации.");
                            }
                        }
                        break;
                    case 0:
                        exit = false;
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
