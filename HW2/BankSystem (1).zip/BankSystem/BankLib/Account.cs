﻿using System;


namespace BankLib
{
    public class Account
    {
        #region FIELD
        private string numOfPassport;

        public string NumOfPassport
        {
            get { return numOfPassport; }
        }

        private int numOfAccIp;

        public int NumOfAccIp
        {
            get { return numOfAccIp; }
        }

        const int percentOfBank = 5;

        public int PercentOfBank
        {
            get { return percentOfBank; }
        }

        private int deposit;

        public int Deposit
        {
            get { return deposit; }
            set { deposit = value; }
        }

        #endregion

        #region CTOR
        public Account(string _numOfPassport)
        {
            numOfPassport = _numOfPassport;
            numOfAccIp = Rand.Rnd;
            deposit = 0;
        }
        #endregion
    }
}
