﻿using System;


namespace BankLib
{
    class Rand
    {
        static Random rnd = new Random();
        
        public static int Rnd
        {
            get { return rnd.Next(); }
        }

    }
}
