﻿using System;

namespace BankLib
{
    public class Banksecurity
    {
        /// <summary>
        /// Checking the length of the password and using uppercase characters
        /// </summary>
        /// <param name="passwd">password</param>
        /// <returns></returns>
        public static bool SecurityCheckPasswd(string passwd)
        {
            if (passwd.Length < 6)
            {
                return false;
            }

            for (int i = 0; i < passwd.Length; i++)
            {
                if (Char.IsUpper(passwd[i]))
                {
                    return true;
                }
            }
            return false;
        }

        public static bool PasswdVerification(string enteredPasswd, string originalPasswd)
        {
            if (enteredPasswd == originalPasswd)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool LoginVerification(string enteredLogin, string originalLogin)
        {
            if (enteredLogin == originalLogin)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Checking the correct passport number
        /// 8, 12 and 13 the character must be a letter (denotes region code and citizenship)
        /// other character is numbers
        /// </summary>
        /// <param name="numOfPassport"></param>
        /// <returns></returns>
        public static bool CheckNumOfPassport(string numOfPassport)
        {
            if (numOfPassport.Length != 14)
            {
                return false;
            }
            for (int i = 0; i < numOfPassport.Length; i++)
            {
                if (i != 7 && (i != 11 && i != 12))
                {
                    if (char.IsLetter(numOfPassport[i]))
                    {
                        return false;
                    }
                }
                else
                {
                    if (char.IsDigit(numOfPassport[i]))
                    {
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
