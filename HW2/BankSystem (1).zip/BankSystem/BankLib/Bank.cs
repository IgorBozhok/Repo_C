﻿using System;

namespace BankLib
{
    public class Bank
    {
        #region FIELD
        private string _name;

        public string Name
        {
            get { return _name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Name is not correct...");
                }
                _name = value;
            }
        }

        private Client[] _clients;

        private const int COUNT_CLIENTS = 10;
        #endregion

        #region CTOR

        public Bank(string name)
        {
            Name = name;
            _clients = new Client[COUNT_CLIENTS];
        }
        #endregion

        #region METHODS

        /// <summary>
        /// search for a free element of an array of type Account
        /// </summary>
        /// <returns>
        /// -1 : if array is full
        /// otherwise returns the index of the free cell of the array
        /// </returns>
        private int SearchAFreeElem()
        {
            for (int i = 0; i < _clients.Length; i++)
            {
                if (_clients[i] == null)
                {
                    return i;
                }
            }
            return -1;
        }

        public Client EnterToClient(string login, string passwd)
        {
            for (int i = 0; i < _clients.Length; i++)
            {
                if (Banksecurity.LoginVerification(login, _clients[i].Login))
                {
                    if (Banksecurity.PasswdVerification(passwd, _clients[i].Passwd))
                    {
                        return _clients[i];
                    }
                }
            }
            return null;
        } 

        public bool AddClient(Client client)
        {
            if (client == null)
            {
                throw new ArgumentNullException("client is null");
            }

            int index = SearchAFreeElem();

            if (index == -1)
            {
                return false;
            }
            else
            {
                _clients[index] = client;
                return true;
            }
        }
        #endregion
    }
}
